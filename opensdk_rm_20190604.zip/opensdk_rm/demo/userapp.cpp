/***********************************************************************
������Ҫʵ���˶�RS485�˿�д�����Ŀ���ʾ��������Ҫ��RS485�������Կ�����ʱ��
�����ο�������ֻ��Ҫ�޸��������ɣ�
1 �Զ���ꡰIVSRESULECMD��
2 �Զ������ݽṹ��IVSResultAndLPWLInfo��
3 �޸���Ϣ���ͺ�����OSAMbxSend485��
***********************************************************************/
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
// #include "osa_mbx.h"
// #include "osa_tsk.h"
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <stddef.h>
#include "OpenDevSDK.h"
#include "OpenDevSDKDefines.h"
#include "VzLPRClientSDK_WhiteListDefine.h"
#include "iconv.h"

#include <iostream>

// OSA_MbxHndl m_mbx;       //OSA ��Ϣ���� handle
// OSA_TskHndl m_tsk;

void* g_serial_handle = NULL;

#define IVSRESULECMD    1     //OSA ����������Ϣ�ص�
#define PLATELENGTH     8     //���Ƴ���

//�û��Զ���ṹ�壬����ʱ�����Զ���
typedef struct
{
  IVS_RESULT_PARAM_0 pIVSResult;  //���������Ϣ�ṹ��
  VZ_LPWL_INFO pWListInfo;        //��չ��Ϣ�ṹ��
}IVSResultAndLPWLInfo;


bool WriteImgFile(const char *filepath, unsigned char *pData, unsigned int len)
{
	int num = 0;

	FILE *fp = NULL;
	fp = fopen(filepath, "wb+");

	if (fp == NULL)
	{
		return false;
	}

	num = fwrite(pData, sizeof(char), len, fp);
	fclose(fp);

	return num > 0;
}

bool WriteTxtFile(const char *filepath, char *pData, unsigned int len)
{
	int num = 0;

	FILE *fp = NULL;
	fp = fopen(filepath, "a+");

	if (fp == NULL)
	{
		return false;
	}

	num = fwrite(pData, sizeof(char), len, fp);
	fclose(fp);

	return num > 0;
}

//�������ͻص�����
void OnGetIVSResult2(const IVS_RESULT_PARAM_0 *pIVSResult
                        , const VZ_LPWL_INFO *pWListInfo
                        , void* pUserData)
{
	// ����ʶ����ͼƬ
	if ( pIVSResult != NULL)
	{
		printf("pIVSResult != NULL, plate: %s, path:%s\n", pIVSResult->plateInfo.license, pIVSResult->imagepath);
                printf("result time: %d-%02d-%02d %02d:%02d:%02d\n", pIVSResult->plateInfo.struBDTime.bdt_year, pIVSResult->plateInfo.struBDTime.bdt_mon, pIVSResult->plateInfo.struBDTime.bdt_mday,
				pIVSResult->plateInfo.struBDTime.bdt_hour, pIVSResult->plateInfo.struBDTime.bdt_min, pIVSResult->plateInfo.struBDTime.bdt_sec);
		/*unsigned int uSizeBuf = 512 * 1024;
		unsigned char *imgBuf = (unsigned char*)malloc(uSizeBuf);
		 int ret = VzOSDK_SaveCachedImgToBuf(pIVSResult->imagepath, imgBuf, uSizeBuf);
		 printf("buf size: %d\n", ret);
		 if (ret > 0)
		{
			WriteImgFile("plate.jpg", imgBuf, ret);

			printf("WriteImgFile\n");
		}

		free(imgBuf);
                */
	}

  //OSA �����ڴ�ռ䣨���ݽ��� OSA ���ƣ�
  /*
  void* ivsResultAndLpwl = OSA_memAlloc(sizeof(IVSResultAndLPWLInfo));

  printf("pWListInfo ucWLResult is %d\n",pWListInfo->ucWLResult);

  memcpy(&((IVSResultAndLPWLInfo*)ivsResultAndLpwl)->pIVSResult,pIVSResult,sizeof(IVS_RESULT_PARAM_0));
  memcpy(&((IVSResultAndLPWLInfo*)ivsResultAndLpwl)->pWListInfo,pWListInfo,sizeof(VZ_LPWL_INFO));

  //�� OSA ��Ϣ���� mbx_handle ��������Ϊ IVSRESULECMD ����Ϊ ivsResultAndLpwl ����Ϣ��OSA_MBX_FREE_PRM �����ڴ��ͷŽ��� OSA ͳһ������
  OSA_tskSendNotifyMsg(&m_tsk, NULL, IVSRESULECMD, ivsResultAndLpwl, OSA_MBX_FREE_PRM);
  */
}

/*
int OSAMbxSend485(OSA_TskHndl *pPrc, OSA_MsgHndl *pMsg, Uint32 curState)
{
	Uint16 cmd = 0;
	cmd = OSA_msgGetCmd(pMsg);
	if (cmd == IVSRESULECMD)
	{
		IVSResultAndLPWLInfo *pIVSResultAndLpwl = (IVSResultAndLPWLInfo*)OSA_msgGetPrm(pMsg);
		char *pLicense = pIVSResultAndLpwl->pIVSResult.plateInfo.license;

		//1���λ
		VzOSDK_asynSetIOOutputStateAuto(GPIO_OUT1, 1000);

		OSA_tskAckOrFreeMsg(pMsg, OSA_SOK);
	}

	bool bNeedAck = false;
	bool bDone = false;
	while (!bDone)
	{
		int rt = OSA_tskCheckMsg(&m_tsk, &pMsg);
		if (rt == OSA_SOK)
		{
			
			cmd = OSA_msgGetCmd(pMsg);
			if (cmd == MSG_TASK_DELETE)
			{
				bDone = true;
				bNeedAck = true;	//���ѭ��ʱ��ACK
			}
			else if (cmd == IVSRESULECMD)
			{
				// ��ȡ msg_handle ���������
				IVSResultAndLPWLInfo *pIVSResultAndLpwl = (IVSResultAndLPWLInfo*)OSA_msgGetPrm(pMsg);
				
				char *pLicense = pIVSResultAndLpwl->pIVSResult.plateInfo.license;
				
				//���� 485 ��Ϣ������ 485 ��Ϣ���ڸ��߳̽���ʵ�֣�
				 // VzOSDK_asynWriteDataToRS485(handle,(const unsigned char*)pLicense,PLATELENGTH);
				
				//1���λ
				VzOSDK_asynSetIOOutputStateAuto(GPIO_OUT1, 1000);
			}

			if (!bNeedAck)
			{
				OSA_tskAckOrFreeMsg(pMsg, OSA_SOK);
			}
		}
		else
		{
			usleep(10);
		}
	}

	return(0);
}
*/

//�������ʹ�������Ļص�����
void OnIOInput(GPIO_IN eId, int bValue, void* pUserData)
{
  printf("OnIOInput(%d) = %d\n", eId, bValue);
}

//һ�����ȡ���� 485 ��Ϣ�ڴ˴���
void OnSerialRead(void *handleDev, DEV_485 eId, const unsigned char *pData,
                  unsigned uSizeData, void* pUserData)
{
  printf("Serial(%d)Read: Size = %u\n", eId, uSizeData);

  if(strlen((const char *)pData) + 1 == uSizeData)
  {
    printf("%s\n", (const char *)pData);
  }
  else
  {
    for(unsigned i=0; i<uSizeData; i++)
    {

      printf("0x%02x ", pData[i]);

      if(((i + 1) % 10) == 0)
        printf("\n");
    }
    printf("\n");
  }
}

void OnUserWebRequestionData(unsigned uRequestId, const unsigned char *pData,
	unsigned uSizeData, void* pUserData)
{
	printf("http request data: %s\n", pData);

	VzOSDK_SendUserWebReponseData(uRequestId, "987654321", 10);
}

void OnDGTypeChange(int entranceInfo, bool bEnable, void* pUserData)
{
	if (bEnable)
	{
		printf("enable DG group. entranceInfo: %d \n", entranceInfo);
	}
	else
	{
		printf("disable DG group. \n");
	}
}

void OnOfflineStatusCallBack(int nStatus, void* pUserData)
{
	char szValue[32] = { 0 };
	sprintf(szValue, "offline status: %d\r\n", nStatus);
	WriteTxtFile("test2.txt", szValue, strlen(szValue));
	// printf("offline status: %d\n", nStatus);
}

 void  OnTcpServerUserData(const  char *pBufData, unsigned uSizeData, void* pUserData)
 {
 	    printf("recv Tcp sever user data:%s,size:%d",pBufData,uSizeData);
 }
 
 /*
 static void exit_signal(int signum)
{
	printf("\n exit signal.\n");

	if( g_serial_handle != NULL )
	{
		VzOSDK_asynCloseRS485(g_serial_handle);
		g_serial_handle = NULL;
	}
	
	// OSA_mbxDelete(&m_mbx);
	VzOSDK_Release();
	
	exit(EXIT_SUCCESS);
}
*/

int main(int argc, char* argv[])
{
	printf("start 222. \n");

	// ����osa����
	// OSA_mbxCreate(&m_mbx);

	// ����osa�߳�
	// OSA_tskCreate(&m_tsk, OSAMbxSend485, 0, OSA_THR_PRI_MAX - 1, 50 * 1024, 0);

	VzOSDK_Init();

	char szIP[32] = { 0 };
	int ret = VzOSDK_GetDevIP(szIP);
	printf("device ip: %s, ret:%d\n", szIP, ret);

	//����ʶ�����Ļص�����
	VzOSDK_SetIVSResultCallBackEx2(OnGetIVSResult2, NULL);

	//����IO����Ļص�����
	VzOSDK_SetIOInCallBack(OnIOInput, NULL);
        VzOSDK_ForceTrigger();
/*
	VZ_TM oTime;
	oTime.nYear = 2017;	//��
	oTime.nMonth = 8;	//��
	oTime.nMDay = 15;	//��
	oTime.nHour = 20;	//ʱ
	oTime.nMin = 5;		//��
	oTime.nSec = 30;		//��
	ret = VzOSDK_SetDevTime(&oTime);

	printf("VzOSDK_SetDevTime ret: %d\n", ret);
*/
       // int ret_set = VzOSDK_SetDevUndelegated(1);
        // printf("SetDevUndelegated :%d\n", ret_set);

        // int dev_state = -1;
        // int ret_get = VzOSDK_GetDevUndelegated(&dev_state);
        // printf("GetDevUndelegated ret:%d, dev_state:%d.\n", ret_get, dev_state);

	// 485�ӿ�
	g_serial_handle = VzOSDK_asynOpenRS485(DEV_485_0, OnSerialRead, NULL);
	if (g_serial_handle)
	{
		printf("g_serial_handle is not nullptr\n");

		char buffer[512] = {0};
		// strcpy(buffer, "123456");
		memset(buffer, '3', 500);

		VzOSDK_asynWriteDataToRS485(g_serial_handle, (unsigned char*)buffer, 256);
	}



	// д���û�����
	char user_data[128] = { 0 };
	int len = 0;
	int ret2 = VzOSDK_syncGetUserData(user_data, &len);
	for(int i = 0; i < len; i++)
	{
		printf("userdata :%02x\n", (unsigned char)user_data[i]);
	}

	printf("VzOSDK_syncGetUserData11 : %s ret:%d\n", user_data, ret2);
	

	char user_data_msg[128] = { 0 };
	sprintf(user_data_msg, "get userdata : %s ret:%d\n", user_data, ret2);
	WriteTxtFile("test.txt", user_data_msg, strlen(user_data_msg));
	
	//ret2 = VzOSDK_asynSetUserData("234234", strlen("234234"));
	//printf("VzOSDK_asynSetUserData ret:%d\n", ret2);

	// memset(user_data, 0, sizeof(user_data));
	// ret2 = VzOSDK_syncGetUserData(user_data, &len);
	// printf("VzOSDK_syncGetUserData22 : %s ret:%d\n", user_data, ret2);
	
	ret2 = VzOSDK_WriteUserLog("test log", strlen("test log"));
	printf("VzOSDK_WriteUserLog : ret:%d\n", ret2);
	
	int count = 0;
	ret2 = VzOSDK_GetWhiteListTotalCount(&count);
	printf("VzOSDK_GetWhiteListTotalCount : ret:%d, count: %d\n", ret2, count);
	
	char szSnapImgPath[256] = {0};
        strcpy(szSnapImgPath, "test.jpg");	
	ret2= VzOSDK_GetSnapImgPath(szSnapImgPath, 256);
	printf("VzOSDK_GetSnapImgPath : ret:%d, snap path: %s\n", ret2, szSnapImgPath);
	
          unsigned int uSizeBuf = 512 * 1024;
                unsigned char *imgBuf = (unsigned char*)malloc(uSizeBuf);
                 ret = VzOSDK_SaveCachedImgToBuf(szSnapImgPath, imgBuf, uSizeBuf);
                 printf("buf size: %d\n", ret);
                 if (ret > 0)
                {
                        WriteImgFile("test.jpg", imgBuf, ret);

                        printf("WriteImgFile\n");
                }

                free(imgBuf);

	int gpio_value1 = 0;
	ret2 = VzOSDK_syncGetGpioValue(GPIO_IN1, &gpio_value1);
	printf("VzOSDK_syncGetGpioValue 0 value: %d ret:%d\n", gpio_value1, ret2);	

	int gpio_value2 = 0;
	ret2 = VzOSDK_syncGetGpioValue(GPIO_IN2, &gpio_value2);
	printf("VzOSDK_syncGetGpioValue 1 value: %d ret:%d\n", gpio_value2, ret2);	
	
		//�ж�/�ָ�ԭ���豸���ƵĴ��������1��ʾ�ж��豸�����0��ʾ�ָ��豸���
	//�ж��豸�����������ʱ����ģ�鲻����ⷢ�� 485,ֻ�б������� 485
	//�������ⲿ�ն˿����յ����� 485 ��Ϣ��
	VzOSDK_asynHaltOriginalSerialOutput(true);
	
	// ���ý����û���ҳ���ݵĻص�����
	VzOSDK_SetUserWebRequestionDataCallBack(OnUserWebRequestionData, NULL);

	/*
	int entranceInfo = 0;
	int ret2 = VzOSDK_GetEntranceInfo(&entranceInfo);
	printf("VzOSDK_GetEntranceInfo ret: %d, value:%d\n", ret2, entranceInfo);
	// VzOSDK_PlayVoice("12312", 10, 90, 1);

	//ret2 = VzOSDK_SetAdminpass("123456", "123456");
	//printf("VzOSDK_SetAdminpass ret: %d\n", ret2);

	//ret2 = VzOSDK_RebootDev();
	//printf("VzOSDK_RebootDev ret: %d\n", ret2);

	// ���ý����û���ҳ���ݵĻص�����
	VzOSDK_SetUserWebRequestionDataCallBack(OnUserWebRequestionData, NULL);

	// �����������øı�Ļص�����
	VzOSDK_SetDGTypeChangeCallBack(OnDGTypeChange, NULL);

	// �����ѻ����Ļص�
	

	bool config = false;
	VzOSDK_syncGetDGConfigStatus(&config);
	printf("VzOSDK_syncGetDGConfigStatus ret: %d.\n", config);

	g_serial_handle = VzOSDK_asynOpenRS485(DEV_485_0, OnSerialRead, NULL);
	if (g_serial_handle)
	{
		printf("g_serial_handle is not nullptr\n");
	}
	*/

VzOSDK_SetOfflineStatusCallBack(OnOfflineStatusCallBack, NULL);

	BLDB_LPR_REC pBldbLprRec;
	memset(&pBldbLprRec, 0, sizeof(BLDB_LPR_REC));

	// VzOSDK_asynClearWhiteListCustomersAndVehicles();
	
	// ע���˳��ź�;
	// signal(SIGINT, exit_signal);
	
	while (true)
	{
		usleep(100);
	}

	return 0;
}
