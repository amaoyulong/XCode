# !/bin/sh
sleep 20
LD_LIBRARY_PATH=. ./userapp &